"""engines_v3/fragility_engine.py - Fragility Engine (F0-F5) [修复版]"""
import sqlite3
import pandas as pd
import numpy as np
import json
from datetime import datetime

DB_PATH = 'data/macro.db'


def _load(conn, sid, limit=120):
    for col in ['timestamp', 'date']:
        try:
            df = pd.read_sql_query(
                f"SELECT {col} AS dt, value FROM observations WHERE series_id=? ORDER BY {col} DESC LIMIT ?",
                conn, params=(sid, limit)
            )
            if not df.empty:
                df['dt'] = pd.to_datetime(df['dt'], errors='coerce')
                df = df.dropna(subset=['dt']).drop_duplicates(subset=['dt'], keep='first')
                return df.sort_values('dt').set_index('dt')['value'].astype(float)
        except Exception:
            continue
    return pd.Series(dtype=float)


def _scale(value, lo, hi):
    """线性映射到 0-100，自动截断"""
    try:
        v = float(value)
        if pd.isna(v):
            return 50.0
        return float(np.clip((v - lo) / (hi - lo) * 100, 0, 100))
    except Exception:
        return 50.0


# ============ 9 个维度 ============

def calc_liquidity(conn):
    rrp = _load(conn, 'RRP_BALANCE', 30)
    res = _load(conn, 'RESERVE_BALANCE', 30)
    sofr = _load(conn, 'SOFR', 30)
    effr = _load(conn, 'EFFR', 30)
    score, comp = 0.0, {}
    if len(rrp) >= 1:
        s = _scale(2000 - float(rrp.iloc[-1]), 0, 2000)
        comp['RRP'] = round(s, 1)
        score += s * 0.4
    if len(res) >= 5:
        r_now, r_4w = float(res.iloc[-1]), float(res.iloc[-min(4, len(res))])
        chg = (r_now - r_4w) / r_4w if r_4w else 0
        s = _scale(-chg, -0.05, 0.05)
        comp['Reserves'] = round(s, 1)
        score += s * 0.3
    if len(sofr) >= 1 and len(effr) >= 1:
        spread = (float(sofr.ffill().iloc[-1]) - float(effr.ffill().iloc[-1])) * 100
        s = _scale(spread, -2, 10)
        comp['SOFR-EFFR'] = round(s, 1)
        score += s * 0.3
    return min(score, 100), comp


def calc_leverage(conn):
    vix = _load(conn, 'VIX', 60)
    jpy = _load(conn, 'USD_JPY', 60)
    score, comp = 0.0, {}
    if len(jpy) >= 21:
        vol = float(jpy.pct_change().tail(20).std() * (252 ** 0.5))
        s = _scale(vol, 0.05, 0.15)
        comp['JPY_Vol'] = round(s, 1)
        score += s * 0.6
    if len(vix) >= 20:
        vol = float(vix.pct_change().tail(20).std())
        s = _scale(vol, 0.02, 0.08)
        comp['VIX_Vol'] = round(s, 1)
        score += s * 0.4
    return min(score, 100), comp


def calc_funding(conn):
    sofr = _load(conn, 'SOFR', 30)
    effr = _load(conn, 'EFFR', 30)
    res = _load(conn, 'RESERVE_BALANCE', 30)
    score, comp = 0.0, {}
    if len(sofr) >= 5 and len(effr) >= 5:
        spread = (float(sofr.ffill().iloc[-1]) - float(effr.ffill().iloc[-1])) * 100
        s = _scale(spread, -2, 10)
        comp['Spread'] = round(s, 1)
        score += s * 0.5
    if len(res) >= 5:
        s = _scale(3200000 - float(res.iloc[-1]), 0, 400000)
        comp['Reserves'] = round(s, 1)
        score += s * 0.5
    return min(score, 100), comp


def calc_crowding(conn):
    try:
        df = pd.read_sql_query(
            "SELECT stress_score FROM positioning_engine ORDER BY asof_date DESC LIMIT 1", conn
        )
        if not df.empty:
            v = float(df.iloc[0]['stress_score'])
            return min(v, 100), {'Positioning': round(v, 1)}
    except Exception:
        pass
    return 50.0, {'Positioning': 50.0}


def calc_mismatch(conn):
    y10 = _load(conn, 'YC10Y', 30)
    y30 = _load(conn, 'YC30Y', 30)
    tga = _load(conn, 'TGA_BALANCE', 30)
    score, comp = 0.0, {}
    if len(y30) >= 1 and len(y10) >= 1:
        curve = float(y30.iloc[-1]) - float(y10.iloc[-1])
        s = _scale(curve, 0, 1.0)
        comp['Curve_30_10'] = round(s, 1)
        score += s * 0.6
    if len(tga) >= 5:
        t_now, t_4w = float(tga.iloc[-1]), float(tga.iloc[-min(4, len(tga))])
        chg = abs((t_now - t_4w) / t_4w) if t_4w else 0
        s = _scale(chg, 0, 0.20)
        comp['TGA_Vol'] = round(s, 1)
        score += s * 0.4
    return min(score, 100), comp


def calc_valuation(conn):
    spx = _load(conn, 'SP500', 60)
    hyg = _load(conn, 'HY_SPREAD', 60)
    score, comp = 0.0, {}
    if len(spx) >= 20:
        chg = (float(spx.iloc[-1]) - float(spx.iloc[-min(20, len(spx))])) / float(spx.iloc[-min(20, len(spx))])
        s = _scale(chg, -0.05, 0.10)
        comp['SPX_Mom'] = round(s, 1)
        score += s * 0.5
    if len(hyg) >= 1:
        s = _scale(5.0 - float(hyg.iloc[-1]), -3, 3)
        comp['HY_Spread'] = round(s, 1)
        score += s * 0.5
    return min(score, 100), comp


def calc_correlation(conn):
    """修复：不再重复 * 100"""
    try:
        df = pd.read_sql_query(
            "SELECT avg_corr_20d FROM contagion_engine ORDER BY asof_date DESC LIMIT 1", conn
        )
        if not df.empty:
            corr = float(df.iloc[0]['avg_corr_20d'])
            # 相关性 0-1，映射到 0-100
            s = _scale(corr, 0, 0.5)
            return s, {'Corr': round(s, 1)}
    except Exception:
        pass
    return 50.0, {'Corr': 50.0}


def calc_policy(conn):
    y2 = _load(conn, 'YC2Y', 30)
    mich = _load(conn, 'MICH_1Y_EXPECT', 12)
    score, comp = 0.0, {}
    if len(y2) >= 20:
        vol = float(y2.diff().tail(20).std())
        s = _scale(vol, 0.02, 0.15)
        comp['2Y_Vol'] = round(s, 1)
        score += s * 0.6
    if len(mich) >= 2:
        chg = abs(float(mich.iloc[-1]) - float(mich.iloc[-2]))
        s = _scale(chg, 0, 1.0)
        comp['MICH'] = round(s, 1)
        score += s * 0.4
    return min(score, 100), comp


def calc_market_depth(conn):
    """修复：不再重复 * 100"""
    vix = _load(conn, 'VIX', 60)
    if len(vix) >= 20:
        vol = float(vix.pct_change().tail(20).std())
        s = _scale(vol, 0.02, 0.08)
        return s, {'VIX_Disp': round(s, 1)}
    return 50.0, {'VIX_Disp': 50.0}


DIMENSIONS = [
    ('Liquidity',    calc_liquidity,    0.15),
    ('Leverage',     calc_leverage,     0.15),
    ('Funding',      calc_funding,      0.15),
    ('Crowding',     calc_crowding,     0.10),
    ('Mismatch',     calc_mismatch,     0.10),
    ('Valuation',    calc_valuation,    0.10),
    ('Correlation',  calc_correlation,  0.08),
    ('Policy',       calc_policy,       0.10),
    ('MarketDepth',  calc_market_depth, 0.07),
]


def calc_amplification(scores):
    high = sum(1 for v in scores.values() if v > 60)
    very_high = sum(1 for v in scores.values() if v > 75)
    amp = 1.0
    if high >= 2: amp += 0.15
    if high >= 4: amp += 0.15
    if high >= 6: amp += 0.15
    if very_high >= 2: amp += 0.15
    if very_high >= 4: amp += 0.15
    return round(min(amp, 2.0), 3)


def to_level(score):
    if score < 20: return 'F0_RESILIENT'
    elif score < 35: return 'F1_NORMAL'
    elif score < 50: return 'F2_VULNERABLE'
    elif score < 65: return 'F3_FRAGILE'
    elif score < 80: return 'F4_HIGHLY_FRAGILE'
    return 'F5_PRE_CRISIS'


def compute_fragility(asof: str) -> dict:
    conn = sqlite3.connect(DB_PATH)
    scores, details = {}, {}
    try:
        for name, fn, w in DIMENSIONS:
            try:
                s, comp = fn(conn)
                # 强制截断到 0-100
                s = float(np.clip(s, 0, 100))
                scores[name] = s
                details[name] = {'score': round(s, 1), 'components': comp, 'weight': w}
            except Exception as e:
                scores[name] = 50.0
                details[name] = {'score': 50.0, 'error': str(e)[:60], 'weight': w}
    finally:
        conn.close()

    base = sum(scores[n] * w for n, _, w in DIMENSIONS)
    amp = calc_amplification(scores)
    final = min(base * amp, 100)
    level = to_level(final)

    result = {
        'asof': asof,
        'fragility_score': round(final, 1),
        'base_fragility': round(base, 1),
        'amplification': amp,
        'level': level,
        'dimensions': details
    }

    conn = sqlite3.connect(DB_PATH)
    conn.execute("""CREATE TABLE IF NOT EXISTS fragility_engine (
        asof_date TEXT PRIMARY KEY, fragility_score REAL, base_fragility REAL,
        amplification REAL, level TEXT, detail TEXT)""")
    conn.execute("""INSERT OR REPLACE INTO fragility_engine
        (asof_date, fragility_score, base_fragility, amplification, level, detail)
        VALUES (?, ?, ?, ?, ?, ?)""",
        (asof, final, base, amp, level, json.dumps(details)))
    conn.commit()
    conn.close()

    print(f"\n{'='*60}")
    print(f"  Fragility Engine - {asof}")
    print(f"{'='*60}")
    print(f"  Base Fragility:  {base:.1f}")
    print(f"  Amplification:   x{amp}")
    print(f"  Final Score:     {final:.1f}")
    print(f"  Level:           {level}\n")
    for n, _, w in DIMENSIONS:
        d = details[n]
        bar = '#' * int(d['score'] / 5)
        print(f"  {n:12s} [{w*100:4.0f}%] {d['score']:5.1f} {bar}")
    print(f"{'='*60}\n")
    return result


if __name__ == "__main__":
    compute_fragility(datetime.now().strftime('%Y-%m-%d'))